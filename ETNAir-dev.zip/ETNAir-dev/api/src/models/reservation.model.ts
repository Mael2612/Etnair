import { PrismaClient, Prisma } from '@prisma/client';

const prisma = new PrismaClient();

export class ReservationModel {
    static async create() {
        throw new Error("Method not implemented.");
    }
    static async cancel() {
        throw new Error("Method not implemented.");
    }
    static async update() {
        throw new Error("Method not implemented.");
    }

}