import { PrismaClient, Prisma } from '@prisma/client';

const prisma = new PrismaClient();

export class ReviewModel {
    static async create() {
        throw new Error("Method not implemented.");
    }
    static async delete() {
        throw new Error("Method not implemented.");
    }
    static async deleteAll() {
        throw new Error("Method not implemented.");
    }
    static async update() {
        throw new Error("Method not implemented.");
    }

}