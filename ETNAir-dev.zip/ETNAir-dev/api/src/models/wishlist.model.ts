import { PrismaClient, Prisma } from '@prisma/client';

const prisma = new PrismaClient();

export class WishlistModel {

    static async add() {
        throw new Error("Method not implemented.");
    }
    static async create() {
        throw new Error("Method not implemented.");
    }
    static async delete() {
        throw new Error("Method not implemented.");
    }
    static async deleteInWishlist() {
        throw new Error("Method not implemented.");
    }

}