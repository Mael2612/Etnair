import { Router } from 'express';

const PropertyRouter = Router();


export default PropertyRouter;