import { body } from "express-validator/lib/middlewares/validation-chain-builders";

export const editUser = [
    // TODO : check all input of the proccess
];