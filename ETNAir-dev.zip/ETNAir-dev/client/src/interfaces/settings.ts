export interface settings {
    menuItem: string;
    value: string;
}