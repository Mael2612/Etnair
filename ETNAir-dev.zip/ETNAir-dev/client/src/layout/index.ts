export { default as AccountLayout } from './AccountLayout';
export { default as AdminLayout } from './AdminLayout';
export { default as AuthentificationLayout } from './AuthentificationLayout';
export { default as HostingLayout } from './HostingLayout';
export { default as MainLayout } from './MainLayout';
