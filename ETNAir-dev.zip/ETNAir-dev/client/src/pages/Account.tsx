function Account() {

    return (
        <div>
            <h1>Welcome to the Account Page</h1>
        </div>
    );
}

export default Account;