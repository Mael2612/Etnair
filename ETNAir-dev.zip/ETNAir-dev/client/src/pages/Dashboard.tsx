function Dashboard() {

    return (
        <div>
            <h1>Welcome to the Dashboard Page</h1>
        </div>
    );
}

export default Dashboard;