function Hosting() {

    return (
        <div>
            <h1>Welcome to the Hosting Page</h1>
        </div>
    );
}

export default Hosting;