function Rservation() {

    return (
        <div>
            <h1>Welcome to the Rservation Page</h1>
        </div>
    );
}

export default Rservation;