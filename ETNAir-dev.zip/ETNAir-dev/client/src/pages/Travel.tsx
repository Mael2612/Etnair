function Travel() {

    return (
        <div>
            <h1>Welcome to the Travel Page</h1>
        </div>
    );
}

export default Travel;