function User() {

    return (
        <div>
            <h1>Welcome to the User Page</h1>
        </div>
    );
}

export default User;