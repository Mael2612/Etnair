function Wishlist() {

    return (
        <div>
            <h1>Welcome to the Wishlist Page</h1>
        </div>
    );
}

export default Wishlist;