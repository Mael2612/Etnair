
export type Wishlist = {                    
    id: string
    name: string
    userId: string
    createdAt: Date
    updatedAt: Date
};

